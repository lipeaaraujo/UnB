-- =====     << Projeto: aula1exer2 >>     =====
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 31/03/2025
-- Autor(es) ..............: Pedro Lucas Dourado
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 00 Visoes
--         => 00 Perfis (role)
--         => 00 Usuarios
--         => 00 Sequencias
--         => 00 Triggers
--         => 00 Procedimentos
--         => 00 Funcoes
-- 
-- ULTIMAS ATUALIZACOES
--   31/03/2025 => Criação inicial das tabelas para controle de vendas, empregados, produtos e gerentes.
-- 
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula1exer2;

USE aula1exer2;

CREATE TABLE IF NOT EXISTS Gerente (
    cpf CHAR(11) PRIMARY KEY,
    formacao VARCHAR(255),
    email VARCHAR(255),
    nome VARCHAR(255),
    senha VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Empregado (
    cpf CHAR(11) PRIMARY KEY,
    matricula VARCHAR(50),
    nome VARCHAR(255),
    senha VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Produto (
    codigo INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255),
    quantidade_estoque INT
);

CREATE TABLE IF NOT EXISTS Produto_vendido (
    fk_Produto_codigo INT,
    fk_Empregado_cpf CHAR(11),
    nmr_nota_fiscal INT,
    data DATETIME,
    quantidade INT,
    preco FLOAT,
    PRIMARY KEY (fk_Produto_codigo, fk_Empregado_cpf, nmr_nota_fiscal),
    CONSTRAINT FK_Produto_vendido_2 FOREIGN KEY (fk_Produto_codigo) REFERENCES Produto(codigo),
    CONSTRAINT FK_Produto_vendido_3 FOREIGN KEY (fk_Empregado_cpf) REFERENCES Empregado(cpf)
);

CREATE TABLE IF NOT EXISTS Nota_Fiscal (
    nmr_nota_fiscal INT PRIMARY KEY,
    valor_total FLOAT
);

CREATE TABLE IF NOT EXISTS Endereco (
    cep CHAR(8) PRIMARY KEY,
    logradouro VARCHAR(255),
    bairro VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Telefone (
    telefone CHAR(15) PRIMARY KEY,
    cpf_empregado CHAR(11),
    CONSTRAINT FK_Telefone_2 FOREIGN KEY (cpf_empregado) REFERENCES Empregado(cpf)
);

CREATE TABLE IF NOT EXISTS Gerenciado (
    fk_Gerente_cpf CHAR(11),
    fk_Empregado_cpf CHAR(11),
    PRIMARY KEY (fk_Empregado_cpf, fk_Gerente_cpf),
    CONSTRAINT FK_Gerenciado_1 FOREIGN KEY (fk_Gerente_cpf) REFERENCES Gerente(cpf) ON DELETE RESTRICT,
    CONSTRAINT FK_Gerenciado_2 FOREIGN KEY (fk_Empregado_cpf) REFERENCES Empregado(cpf) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS Endereco_Empregado (
    fk_Endereco_cep CHAR(8),
    fk_Empregado_cpf CHAR(11),
    numero INT,
    complemento VARCHAR(255),
    PRIMARY KEY (fk_Endereco_cep, fk_Empregado_cpf),
    CONSTRAINT FK_Endereco_Empregado_1 FOREIGN KEY (fk_Endereco_cep) REFERENCES Endereco(cep) ON DELETE RESTRICT,
    CONSTRAINT FK_Endereco_Empregado_2 FOREIGN KEY (fk_Empregado_cpf) REFERENCES Empregado(cpf) ON DELETE RESTRICT
);
