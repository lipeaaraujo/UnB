INSERT INTO Gerente (cpf, formacao, email, nome, senha)
VALUES
('12783907070', 'Superior', 'gerente1@email.com', 'Samuel da Massa', 'tH$=G{O+,167'),
('74189560022', 'Médio', 'gerente2@email.com', 'Eduardo Ferreira', '8%hHj`JvE487'),
('16396253054', 'Superior', 'gerente3@email.com', 'Hauedy Weusahaxgine', '|11eRM!6a)?@'),
('74859441001', 'Superior', 'gerente4@email.com', 'Camyla Ramos', '8WCn8hIAI.&9');

INSERT INTO Empregado (cpf, matricula, nome, senha)
VALUES
('96934755006', '0224001', 'Pedro Lopes', '4}=T1O:75Qko'),
('83310248003', '0324005', 'Tales Rodrigues', 'Oqvq£77?,F61'),
('62027769005', '0125003', 'Manoel Felipe', '|-9CzX31ju@3');

INSERT INTO Produto (codigo, nome, quantidade_estoque)
VALUES
(1, 'Samsung Galaxy S23', 100),
(2, 'Apple MacBook Pro 16', 150),
(3, 'Sony WH-1000XM5', 200);

INSERT INTO Nota_Fiscal (nmr_nota_fiscal, valor_total)
VALUES
(1001, 23995), 
(1002, 17997),
(1003, 1499);

INSERT INTO Produto_vendido (fk_Produto_codigo, fk_Empregado_cpf, nmr_nota_fiscal, data, quantidade, preco)
VALUES
(1, '96934755006', 1001, '2025-03-31 10:00:00', 2, 2999.00),
(2, '83310248003', 1001, '2025-03-31 10:02:00', 3, 5999.00),
(2, '56789012345', 1002, '2025-03-31 11:00:00', 3, 5999.00),
(3, '67890123456', 1003, '2025-03-31 12:00:00', 1, 1499.00);

INSERT INTO Endereco (cep, logradouro, bairro)
VALUES
('73105903', 'Rodovia DF-150 Km 2,5', 'Grande Colorado (Sobradinho)'),
('70675124', 'Quadra QRSW 1 Bloco B-4', 'Setor Sudoeste'),
('71715045', 'Avenida Segunda Avenida Bloco 1400', 'Núcleo Bandeirante');

INSERT INTO Telefone (telefone, cpf_empregado)
VALUES
('61984214323', '96934755006'),
('61988447783', '83310248003'),
('61994427163', '62027769005');

INSERT INTO Gerenciado (fk_Gerente_cpf, fk_Empregado_cpf)
VALUES
('12783907070', '96934755006'),
('74189560022', '83310248003'),
('74859441001', '62027769005'),
('74859441001', '62027769005');

INSERT INTO Endereco_Empregado (fk_Endereco_cep, fk_Empregado_cpf, numero, complemento)
VALUES
('73105903', '96934755006', 101, 'Plaza'),
('70675124', '83310248003', 202, 'Gammagiore'),
('71715045', '62027769005', 301, 'Residencial Village');
