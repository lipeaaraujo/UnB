USE aula1exer2;

DROP TABLE IF EXISTS Endereco_Empregado;
DROP TABLE IF EXISTS Produto_vendido;     
DROP TABLE IF EXISTS Gerenciado;   
DROP TABLE IF EXISTS Telefone;         
DROP TABLE IF EXISTS Endereco;          
DROP TABLE IF EXISTS Nota_Fiscal;     
DROP TABLE IF EXISTS Produto;          
DROP TABLE IF EXISTS Empregado;       
DROP TABLE IF EXISTS Gerente;            